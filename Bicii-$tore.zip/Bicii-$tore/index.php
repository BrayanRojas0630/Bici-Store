<!DOCTYPE html>
<<!doctype html> 
<html lang="en"> 
<head> 
<meta charset="UTF-8" /> 
<title>Document</title> 
</head> 
<body> 

<?php 

echo "<a href='form.php?id=10'>Diana</a>"; 


?> 


</body> 
</html> 

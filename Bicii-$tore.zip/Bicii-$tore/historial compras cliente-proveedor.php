
<!DOCTYPE html>
<?php

$cantFila=7;
$cantcolumna=5;
         

 echo "<table border=2>";
 
 for ($fila=1;$fila<=$cantFila; $fila++)
 {
  echo "<tr>";
  
  {
  echo "<td> Fila $fila, Columnas $col </td>";
  
  }
  echo "</tr>";
 }
 echo "</table>";
 
 ?>


 
  
 
 
 

        
         
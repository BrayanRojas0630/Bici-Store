
function mostrareldiv() { 

var httr = new XMLHttpRequest(); 
var url = "config.php"; 

document.getElementById('light').style.display='block'; 
document.getElementById('fade').style.display='block'; 
var id = document.getElementById("miventana").dataset.idusuario; 
var variables = "idusuario="+id; 
httr.open("POST",url,true); 
httr.setRequestHeader("Content-type", "application/x-www-form-urlencoded"); 
httr.onreadystatechange = function() 
{ 
if(httr.readyState == 4 && httr.status == 200) 
{ 
var respuesta = httr.responseText; 
document.getElementById("respuesta").innerHTML = respuesta; 

} 
} 

httr.send(variables); 

document.getElementById("respuesta").innerHTML = "procesando"; 
} 

function ocultareldiv() { 
document.getElementById('light').style.display='none'; 
document.getElementById('fade').style.display='none'; 
} 

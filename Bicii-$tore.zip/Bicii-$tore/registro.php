<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
      
        <title>perfil:nombrede usuario</title>
    </head>
             
   
        
        <style>
       div label{
            width: 25%;
        }    
        input{
            border: solid 4px black;
        }       
        
        </style>    
     
            
    </head>
    <body>
        <h1>REGISTRO</h1>
            <form>
                <fieldset>
                     <p>
                        <input type="submit" value ="proveedor">
                        
                        
                     
                        <input type="submit" value ="mensajero">
                        </p>    
                        
                    <p>
                        <label>nombre</label>
                        <input type="text" name="nombre">
                        
                         <label>usuario</label>
                        <input type="text" name="usuario">
                    </p>
                         
                      
                        
                    <p>
                        <label>confirmar</label>
                        <input type="text" name="confirmar">
                    
                        <label>apellido</label>
                        <input type="text" name="apellido">
                        </p>
                        
                         <p>
                        <label>contraseña</label>
                        <input type="text" name="contraseña">
                    
                        <label>numero-cuenta</label>
                        <input type="text" name="numero-cuenta">
                        </p>
                        
                        
                        
                        <p>
                        <input type="submit" value ="guardar">
                        </p> 
                        
                        
                            
  
